//go:build !windows
// +build !windows

package util

var invalidPathChars = []string{`/`, `:`}

import { Blob } from "blob-polyfill";

globalThis.Blob = Blob;
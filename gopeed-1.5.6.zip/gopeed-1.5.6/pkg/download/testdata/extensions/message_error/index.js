gopeed.events.onResolve(async function (ctx) {
    throw new MessageError("test");
});

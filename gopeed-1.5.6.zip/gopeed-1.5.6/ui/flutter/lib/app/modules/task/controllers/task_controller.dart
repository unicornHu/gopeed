import 'package:get/get.dart';

class TaskController extends GetxController {
  final tabIndex = 0.obs;
}

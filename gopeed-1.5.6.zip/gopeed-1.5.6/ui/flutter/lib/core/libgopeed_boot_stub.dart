import 'libgopeed_boot.dart';

LibgopeedBoot create() => throw UnimplementedError();

import 'package:get/get.dart';

class RootController extends GetxController {}

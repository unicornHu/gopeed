// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'install_extension.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

InstallExtension _$InstallExtensionFromJson(Map<String, dynamic> json) =>
    InstallExtension(
      devMode: json['devMode'] as bool? ?? false,
      url: json['url'] as String,
    );

Map<String, dynamic> _$InstallExtensionToJson(InstallExtension instance) =>
    <String, dynamic>{
      'devMode': instance.devMode,
      'url': instance.url,
    };

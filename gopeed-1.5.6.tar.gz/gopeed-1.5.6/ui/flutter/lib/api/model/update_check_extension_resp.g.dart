// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_check_extension_resp.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UpdateCheckExtensionResp _$UpdateCheckExtensionRespFromJson(
        Map<String, dynamic> json) =>
    UpdateCheckExtensionResp(
      newVersion: json['newVersion'] as String,
    );

Map<String, dynamic> _$UpdateCheckExtensionRespToJson(
        UpdateCheckExtensionResp instance) =>
    <String, dynamic>{
      'newVersion': instance.newVersion,
    };

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_extension_settings.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UpdateExtensionSettings _$UpdateExtensionSettingsFromJson(
        Map<String, dynamic> json) =>
    UpdateExtensionSettings(
      settings: json['settings'] as Map<String, dynamic>,
    );

Map<String, dynamic> _$UpdateExtensionSettingsToJson(
        UpdateExtensionSettings instance) =>
    <String, dynamic>{
      'settings': instance.settings,
    };

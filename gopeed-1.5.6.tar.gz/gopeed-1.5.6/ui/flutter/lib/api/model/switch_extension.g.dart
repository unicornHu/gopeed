// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'switch_extension.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SwitchExtension _$SwitchExtensionFromJson(Map<String, dynamic> json) =>
    SwitchExtension(
      status: json['status'] as bool,
    );

Map<String, dynamic> _$SwitchExtensionToJson(SwitchExtension instance) =>
    <String, dynamic>{
      'status': instance.status,
    };

package rest

type Config struct {
	Host string `json:"host"`
	Port int    `json:"port"`
}

gopeed.events.onResolve(async function (ctx) {
    // do nothing for test
});
